﻿using NUnit.Framework;
using System;

namespace FruthPharmacy.Tests
{
    [TestFixture]
    public class Test
    {
        [Test]
        public void TestCase()
        {
        }
    }
}
